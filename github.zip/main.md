---
documentclass: ltjsarticle
title: 設計書
author: tkmt25
header-includes:
  - \usepackage[margin=1in]{geometry}
---

#include section1.md
#include section2.md

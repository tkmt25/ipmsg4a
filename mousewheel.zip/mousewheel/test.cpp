#include <windows.h>
#include <stdio.h>
#include <conio.h>

#include "mousewheel.h"

#pragma comment(lib, "user32.lib")

#define ESC (27)

int main(int argc, char **argv)
{
  MSG msg = {0};

  BOOL isStart = StartHook();
  if (!isStart) {
    printf("start fail!\n");
    return -1;
  }
  printf("hook start!\n");
  
  while (GetMessage(&msg, NULL, 0, 0)) {
    if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) {
      break;
    }
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  
  StopHook();
  printf("hook stop!\n");
  
  return 0;
}

#include "mousewheel.h"
#include <stdio.h>

#pragma comment(lib, "user32.lib")

#pragma data_seg(".HOOKDATA")
HINSTANCE hInst = NULL;
HHOOK hMouseHook = NULL;
HHOOK hKeyHook = NULL;
BOOL IsHook = FALSE;
BOOL IsScrolling = FALSE;
//char SpecialKey = VK_CONTROL;
char SpecialKey = 'A';
#pragma data_seg()

static POINT old = {0};

/*****************************************************************/
BOOL APIENTRY DLLMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
  hInst = hInstance;
  return TRUE;
}

/*****************************************************************/
EXPORT BOOL StartHook()
{
  if (IsHook) {
    return TRUE;
  }
  // �}�E�X�t�b�N
  hMouseHook = SetWindowsHookEx(WH_MOUSE_LL, MouseHookProc, hInst, 0);
  if ( !hMouseHook ) {
    return FALSE;
  }

  // �L�[�t�b�N
  hKeyHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyHookProc, hInst, 0);
  if ( !hKeyHook ) {
    UnhookWindowsHookEx(hMouseHook);
    return FALSE;
  }
  
  IsHook = TRUE;
  return TRUE;
}

/*****************************************************************/
EXPORT BOOL StopHook()
{
  if (IsHook) {
    UnhookWindowsHookEx(hMouseHook);
    UnhookWindowsHookEx(hKeyHook);
  }
  IsHook = FALSE;
  return TRUE;
}

static inline void outlog(const char *txt)
{
  FILE *fp = NULL;
  fopen_s(&fp, "C:\\temp\\wheel.log", "a");
  fprintf(fp, txt);
  fclose(fp);
}

/*****************************************************************/
EXPORT LRESULT CALLBACK KeyHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
  
  if (nCode != HC_ACTION) {
    return CallNextHookEx(hMouseHook, nCode, wParam, lParam);
  }

  //if (wParam == SpecialKey){// && IsScrolling) {
  if (int(wParam) == SpecialKey ) {
    return -1;
  }
  char txt[255];
  sprintf(txt, "pressed %c \n", MapVirtualKey(wParam, 0));
  outlog(txt);

  return CallNextHookEx(hMouseHook, nCode, wParam, lParam);
}

/*****************************************************************/
EXPORT LRESULT CALLBACK MouseHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
  MSLLHOOKSTRUCT *pMsg = (MSLLHOOKSTRUCT*)lParam;
  WPARAM wp = wParam;
  
  if (nCode != HC_ACTION) {
    return CallNextHookEx(hMouseHook, nCode, wParam, lParam);
  }

  if (GetAsyncKeyState(SpecialKey) & 0x8000) {
    INPUT data = {0};
    data.type  = INPUT_MOUSE;
    data.mi.dx = pMsg->pt.x;
    data.mi.dy = pMsg->pt.y;
    data.mi.mouseData = (old.y - pMsg->pt.y) > 0 ? -120 : 120;
    data.mi.dwFlags = MOUSEEVENTF_WHEEL;

    IsScrolling = TRUE;
    SendInput(1, &data, sizeof(data));
    old = pMsg->pt;
    return -1;
  }
  IsScrolling = FALSE;
  
  return CallNextHookEx(hMouseHook, nCode, wParam, lParam);
}

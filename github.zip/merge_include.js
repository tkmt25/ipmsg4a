import System
import System.IO
import System.Text

var args = Environment.GetCommandLineArgs()

function mergeIncludes($file){
    var lines = File.ReadAllLines($file, Encoding.UTF8)
    for (var i = 0; i < lines.length; i++) {
	var match = lines[i].match(/#include\s+(.*)$/)
	if ( match ) {
	    mergeIncludes(match[1])
	}
	else {
	    Console.WriteLine(lines[i])
	}
    }
}

Console.OutputEncoding = Encoding.UTF8
mergeIncludes(args[1])




#pragma once

#include <windows.h>

#define EXPORT extern "C" __declspec(dllexport)

EXPORT BOOL StartHook();
EXPORT BOOL StopHook();

EXPORT LRESULT CALLBACK MouseHookProc(int, WPARAM, LPARAM);
EXPORT LRESULT CALLBACK KeyHookProc(int, WPARAM, LPARAM);
